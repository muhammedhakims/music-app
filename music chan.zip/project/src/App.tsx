import React, { useState, useRef, useEffect } from 'react';
import { Home, Search, Library, Heart, Plus, Volume2, SkipBack, Play, Pause, SkipForward, Repeat, Shuffle, Mic2, ListMusic, Laptop2, Volume1, Maximize2 } from 'lucide-react';

// Sample music data with reliable free audio sources from Pixabay
const sampleTracks = [
  {
    id: 1,
    title: "Sakura Dreams",
    artist: "Yuki Morimoto",
    duration: "1:43",
    cover: "https://source.unsplash.com/random/200x200?japanese,cherry,blossom",
    audioUrl: "https://cdn.pixabay.com/download/audio/2022/01/27/audio_c6b6fe0a2e.mp3"
  },
  {
    id: 2,
    title: "Neon Tokyo",
    artist: "Cyber Beats",
    duration: "2:11",
    cover: "https://source.unsplash.com/random/200x200?tokyo,night",
    audioUrl: "https://cdn.pixabay.com/download/audio/2023/09/24/audio_7b8d0e2ef4.mp3"
  },
  {
    id: 3,
    title: "Kawaii Pop",
    artist: "J-Stars",
    duration: "2:25",
    cover: "https://source.unsplash.com/random/200x200?cute,colorful",
    audioUrl: "https://cdn.pixabay.com/download/audio/2023/09/26/audio_7b13a7e874.mp3"
  },
  {
    id: 4,
    title: "Chill Wave",
    artist: "Lo-Fi Dreams",
    duration: "1:56",
    cover: "https://source.unsplash.com/random/200x200?lofi,music",
    audioUrl: "https://cdn.pixabay.com/download/audio/2023/09/19/audio_ef864856a6.mp3"
  },
  {
    id: 5,
    title: "Digital Rain",
    artist: "Cyber Symphony",
    duration: "2:03",
    cover: "https://source.unsplash.com/random/200x200?cyberpunk,city",
    audioUrl: "https://cdn.pixabay.com/download/audio/2023/09/16/audio_7caf6e4c0e.mp3"
  }
];

function App() {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTrack, setCurrentTrack] = useState(sampleTracks[0]);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(1);
  const audioRef = useRef<HTMLAudioElement>(null);

  useEffect(() => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.play();
      } else {
        audioRef.current.pause();
      }
    }
  }, [isPlaying, currentTrack]);

  const handlePlayPause = () => {
    setIsPlaying(!isPlaying);
  };

  const handleTimeUpdate = () => {
    if (audioRef.current) {
      setCurrentTime(audioRef.current.currentTime);
      setDuration(audioRef.current.duration);
    }
  };

  const handleTrackClick = (track: typeof sampleTracks[0]) => {
    setCurrentTrack(track);
    setIsPlaying(true);
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newVolume = parseFloat(e.target.value);
    setVolume(newVolume);
    if (audioRef.current) {
      audioRef.current.volume = newVolume;
    }
  };

  const formatTime = (time: number) => {
    const minutes = Math.floor(time / 60);
    const seconds = Math.floor(time % 60);
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  return (
    <div className="h-screen bg-black text-white flex flex-col">
      <audio
        ref={audioRef}
        src={currentTrack.audioUrl}
        onTimeUpdate={handleTimeUpdate}
        onEnded={() => setIsPlaying(false)}
      />
      
      {/* Main Content */}
      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar */}
        <aside className="w-64 bg-black p-6 flex flex-col gap-6">
          <div className="space-y-4">
            <h1 className="text-2xl font-bold flex items-center gap-2">
              <Mic2 className="h-8 w-8" />
              Music Chan
            </h1>
            <nav className="space-y-2">
              <a href="#" className="flex items-center gap-4 text-gray-300 hover:text-white transition">
                <Home className="h-6 w-6" />
                Home
              </a>
              <a href="#" className="flex items-center gap-4 text-gray-300 hover:text-white transition">
                <Search className="h-6 w-6" />
                Search
              </a>
              <a href="#" className="flex items-center gap-4 text-gray-300 hover:text-white transition">
                <Library className="h-6 w-6" />
                Your Library
              </a>
            </nav>
          </div>
          
          <div className="space-y-4">
            <div className="space-y-2">
              <button className="flex items-center gap-4 text-gray-300 hover:text-white transition">
                <Plus className="h-6 w-6 p-1 bg-gray-300 text-black rounded-sm" />
                Create Playlist
              </button>
              <button className="flex items-center gap-4 text-gray-300 hover:text-white transition">
                <Heart className="h-6 w-6 p-1 bg-gradient-to-br from-indigo-500 to-pink-500 rounded-sm" />
                Liked Songs
              </button>
            </div>
          </div>

          <div className="flex-1 overflow-y-auto">
            <div className="space-y-2">
              <p className="text-gray-300 hover:text-white transition cursor-pointer">Anime Hits</p>
              <p className="text-gray-300 hover:text-white transition cursor-pointer">J-Pop Mix</p>
              <p className="text-gray-300 hover:text-white transition cursor-pointer">Kawaii Beats</p>
              <p className="text-gray-300 hover:text-white transition cursor-pointer">Study Lo-Fi</p>
            </div>
          </div>
        </aside>

        {/* Main Content Area */}
        <main className="flex-1 bg-gradient-to-b from-indigo-900 to-black p-8 overflow-y-auto">
          <div className="mb-8">
            <h2 className="text-2xl font-bold mb-4">Featured Tracks</h2>
            <div className="grid grid-cols-1 gap-4">
              {sampleTracks.map((track) => (
                <div 
                  key={track.id} 
                  className="flex items-center bg-gray-800/50 hover:bg-gray-800 transition rounded overflow-hidden cursor-pointer"
                  onClick={() => handleTrackClick(track)}
                >
                  <img 
                    src={track.cover}
                    alt={`${track.title} cover`} 
                    className="h-20 w-20 object-cover"
                  />
                  <div className="p-4 flex-1">
                    <h3 className="font-medium">{track.title}</h3>
                    <p className="text-sm text-gray-400">{track.artist}</p>
                  </div>
                  <span className="p-4 text-gray-400">{track.duration}</span>
                </div>
              ))}
            </div>
          </div>

          <div>
            <h2 className="text-2xl font-bold mb-4">Recommended Playlists</h2>
            <div className="grid grid-cols-5 gap-6">
              {[1, 2, 3, 4, 5].map((item) => (
                <div key={item} className="bg-gray-900/50 p-4 rounded-lg hover:bg-gray-900 transition cursor-pointer">
                  <img 
                    src={`https://source.unsplash.com/random/200x200?anime,music&sig=${item}`} 
                    alt="Playlist cover" 
                    className="w-full aspect-square object-cover rounded-md mb-4"
                  />
                  <h3 className="font-medium mb-2">Anime Mix {item}</h3>
                  <p className="text-sm text-gray-400">Top anime songs and covers</p>
                </div>
              ))}
            </div>
          </div>
        </main>
      </div>

      {/* Player */}
      <div className="h-24 bg-gray-900 border-t border-gray-800 p-4">
        <div className="flex items-center justify-between h-full">
          {/* Currently Playing */}
          <div className="flex items-center gap-4 w-1/3">
            <img 
              src={currentTrack.cover}
              alt={currentTrack.title} 
              className="h-14 w-14 rounded"
            />
            <div>
              <h4 className="text-sm font-medium">{currentTrack.title}</h4>
              <p className="text-xs text-gray-400">{currentTrack.artist}</p>
            </div>
            <Heart className="h-5 w-5 text-gray-400 hover:text-white cursor-pointer" />
          </div>

          {/* Player Controls */}
          <div className="flex flex-col items-center gap-2 w-1/3">
            <div className="flex items-center gap-6">
              <Shuffle className="h-5 w-5 text-gray-400 hover:text-white cursor-pointer" />
              <SkipBack className="h-5 w-5 text-gray-400 hover:text-white cursor-pointer" />
              <button 
                onClick={handlePlayPause}
                className="h-8 w-8 flex items-center justify-center bg-white rounded-full hover:scale-105 transition"
              >
                {isPlaying ? (
                  <Pause className="h-5 w-5 text-black" />
                ) : (
                  <Play className="h-5 w-5 text-black" />
                )}
              </button>
              <SkipForward className="h-5 w-5 text-gray-400 hover:text-white cursor-pointer" />
              <Repeat className="h-5 w-5 text-gray-400 hover:text-white cursor-pointer" />
            </div>
            <div className="flex items-center gap-2 w-full">
              <span className="text-xs text-gray-400">{formatTime(currentTime)}</span>
              <div className="h-1 flex-1 bg-gray-600 rounded-full">
                <div 
                  className="h-1 bg-white rounded-full"
                  style={{ width: `${(currentTime / duration) * 100}%` }}
                ></div>
              </div>
              <span className="text-xs text-gray-400">{formatTime(duration)}</span>
            </div>
          </div>

          {/* Volume Controls */}
          <div className="flex items-center gap-4 w-1/3 justify-end">
            <Mic2 className="h-5 w-5 text-gray-400 hover:text-white cursor-pointer" />
            <ListMusic className="h-5 w-5 text-gray-400 hover:text-white cursor-pointer" />
            <Laptop2 className="h-5 w-5 text-gray-400 hover:text-white cursor-pointer" />
            <div className="flex items-center gap-2">
              <Volume1 className="h-5 w-5 text-gray-400 hover:text-white cursor-pointer" />
              <input
                type="range"
                min="0"
                max="1"
                step="0.01"
                value={volume}
                onChange={handleVolumeChange}
                className="w-24 accent-white"
              />
            </div>
            <Maximize2 className="h-5 w-5 text-gray-400 hover:text-white cursor-pointer" />
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;